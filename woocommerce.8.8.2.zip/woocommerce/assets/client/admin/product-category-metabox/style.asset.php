<?php return array('version' => 'e316f1e7c36977e6dd27');
