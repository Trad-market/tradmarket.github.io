<?php return array('version' => '27d896744db370005779');
